function [g]=subgrad(x,y,A,AT,tau)
% [M, N] = size(x);
% for i=1:M
%     for j=1:N
%        if x(i,j)>= 0
%           g(i,j)=1;
%        else
%          g(i,j)=-1;
%        end
%     end
% end
    
    resid =  A(x)-y;
    g =  AT(resid)+ tau*sign(x);
end