function sol=diffh(x)
h=[0 1 -1];
sol=conv2c(x,h);