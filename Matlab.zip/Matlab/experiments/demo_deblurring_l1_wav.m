% Demo of image deblurring, with wavelets. 
% 9*9 uniform blur, and Gaussian noise (SNR = 40 dB).

close all;
clear all;

 addpath ./../src
 addpath ./../utils
 addpath ./../pics
 addpath ./../Rice_Wavelet_Toolbox_2.4
%%%% original image
%x = double( imread('cameraman.tif') );%pr1
%x = double(imread('Heart.png'));%pr2
%x = double(imread('rice.png')); %pr3
%x = double( imread('lena_256.gif') );%pr4
%x=255*phantom(256);%pr5
x =  double(imread('ouarzazate2.jpg')) ;%pr6

%%%%%%%%%%%
ni=1.9; % 1<n_inc 
%tol = 1e-4;%pr1:cameraman----> b=10
%nd=0.35; %0<n_dec<1  
%n1=1.2; % 0<n_1
%tol = 5e-4;%pr2:heart
%nd=0.3; 
%n1=1.2; 
%tol =  5e-4;%pr3:rice
%nd=0.44;%0.44 
%n1=1.16; %1.16
%tol = 5e-4;%pr4:lena
%nd=0.44; 
%n1=1.1; 
%tol = 1e-4;%pr5:phantom
%nd=0.44;
%n1=1.2;
tol =  5e-4;%pr6:ouarzazate
nd=0.44; 
n1=1.2;
%%%tol of SpeRSA
tolP=1e-5;

[M, N] = size(x);

%%%% function handle for uniform blur operator (acts on the image
%%%% coefficients)
h = [1 1 1 1 1 1 1 1 1];
lh = length(h);
h = h/sum(h);
h = [h zeros(1,length(x)-length(h))];
h = cshift(h,-(lh-1)/2);
h = h'*h;

H_FFT = fft2(h);
HC_FFT = conj(H_FFT);

B = @(x) real(ifft2(H_FFT.*fft2(x)));
BT = @(x) real(ifft2(HC_FFT.*fft2(x)));

%%%% wavelet representation
wav = daubcqf(2); % Haar wavelet
levels = 4;

W = @(x) mirdwt_TI2D(x, wav, levels); % inverse transform
WT = @(x) mrdwt_TI2D(x, wav, levels); % forward transform

%%%% true value (in wavelet representation)
WTx = WT(x);

%%%% function handles
A = @(x) B(W(x));
AT = @(x) WT(BT(x));

global calls;
calls = 0;
A = @(x) callcounter(A,x);
AT = @(x) callcounter(AT,x);

%%%%% observation
Bx = B(x);
Psig  = norm(Bx,'fro')^2/(M*N);
BSNRdb = 40;
sigma = norm(Bx-mean(mean(Bx)),'fro')/sqrt(N*M*10^(BSNRdb/10))

y = Bx + sigma*randn(M,N);

%%%% algorithm parameters
lambda = 0.0075; % reg parameter
mu = lambda;
outeriters = 500;

filter_FFT = HC_FFT./(abs(H_FFT).^2 + mu).*H_FFT;
muinv = 1/mu;
invLS = @(x) muinv*( x - WT( real(ifft2(filter_FFT.*fft2( W(x) ))) ) );

invLS = @(x) callcounter(invLS,x);

% 


fprintf('Running CSA...\n')% Nestervo's algorithm with step size control;
[X_CSA,objective_CSA, times_CSA, mses_CSA] = CSA(A,AT,y,h,lambda,W,WT,1,tol, outeriters,n1,ni,nd, WTx, 0);
mse_CSA = norm(x-X_CSA,'fro')^2 /(M*N);
ISNR_CSA = 10*log10( norm(y-x,'fro')^2 / (mse_CSA*M*N) );
cpu_time_CSA = times_CSA(end);

calls_CSA = calls;
calls = 0;

% fprintf('Running FSA2...\n')% Nestervo's algorithm &
% [X_FSA2,objective_FSA2, times_FSA2, mses_FSA2] = fsa_s2(A,AT,y,h,lambda,W,WT,1,tol, outeriters, WTx, 0);
% mse_FSA2 = norm(x-X_FSA2,'fro')^2 /(M*N);
% ISNR_FSA2 = 10*log10( norm(y-x,'fro')^2 / (mse_FSA2*M*N) );
% cpu_time_FSA2 = times_FSA2(end);
% 
% calls_fsa2 = calls;
% calls = 0;

% 



% %%%% with SpaRSA
fprintf('Running SpaRSA...\n')
[x_sparsa,x_debias,objective_sparsa,times_sparsa,debias_start,mses_sparsa,taus]= ...
    SpaRSA(y,A,lambda,...
    'AT', AT, ...
      'StopCriterion',1, ...
      'Monotone', 0, ...
      'True_x',WTx, ...
      'ToleranceA',tolP, ...
      'MAXITERA', outeriters, ...
      'Continuation', 0, ...
      'VERBOSE', 0);
Wx_sparsa = W(x_sparsa);
sparsa_mse = norm(x-Wx_sparsa,'fro')^2 /(M*N);
ISNR_sparsa = 10*log10(  norm(y-x,'fro')^2 / (sparsa_mse*M*N) );
sparsa_time = times_sparsa(end);
% % 
  calls_sparsa = calls;
  calls = 0;
% % 


%%%% display results and plots
%fprintf('FISTA CPU time = %3.3g seconds, calls = %d \titers = %d \tMSE = %3.3g, ISNR = %3.3g dB\n', cpu_time_FISTA, calls_fista, length(objective_FISTA), mse_FISTA, ISNR_FISTA)
fprintf('SpaRSA CPU time = %3.3g seconds, calls = %d \titers = %d \tMSE =%3.3g, ISNR = %3.3g dB\n', sparsa_time, calls_sparsa, length(times_sparsa), sparsa_mse, ISNR_sparsa)
fprintf('CSA\n CPU time = %3.3g seconds, calls = %d \titers = %d \tMSE =%3.3g, ISNR = %3.3g dB\n', cpu_time_CSA, calls_CSA, length(objective_CSA), mse_CSA, ISNR_CSA)
%fprintf('FSA2\n CPU time = %3.3g seconds, calls = %d \titers = %d \tMSE =%3.3g, ISNR = %3.3g dB\n', cpu_time_FSA2, calls_fsa2, length(objective_FSA2), mse_FSA2, ISNR_FSA2)


 %%%%%%%%%
 figure; 
 subplot(2,2,1)
 imagesc(x), colormap gray, axis off, axis equal
 title('Original')
% 
 subplot(2,2,2)
 imagesc(y), colormap gray, axis off, axis equal
 title('Blurred and noisy')
% 
subplot(2,2,3)
imagesc(Wx_sparsa), colormap gray, axis off; axis equal,
title('Estimated using SpaRSA')
% 
subplot(2,2,4)
imagesc(X_CSA), colormap gray, axis off; axis equal,
title('Estimated using CSA')
% % 
  figure;
  semilogy(times_sparsa,objective_sparsa, 'b', 'LineWidth',1.8), hold on, 
  semilogy(times_CSA, objective_CSA,'r--', 'LineWidth',1.8),
  title('Objective function 0.5||y-Ax||_{2}^{2}+\tau||x||_{1}','FontName','Times','FontSize',12),
  set(gca,'FontName','Times'),
  set(gca,'FontSize',12),
  xlabel('seconds'), 
  legend('SpaRSA','CSA');
% 
