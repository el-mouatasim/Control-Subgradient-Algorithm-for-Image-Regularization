I = imread('ouarzazate.JPG');
I=rgb2gray(I);
%imshow(I)
%I = imwrite(I1,'ouarza5.tif');
%figure, imshow(I)
J=imresize(I,[200,200]);
%figure, imshow(J)
imwrite(J,'ouarzazate2.jpg')
%k=imread('ouarzazate2.jpg');
%figure, imshow(k)