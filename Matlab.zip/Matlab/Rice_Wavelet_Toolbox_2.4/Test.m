clc;clear;
im=randn(128, 128);

h = daubcqf(4,'min');
L = 3;
[y,L] = mdwt(im,h,L);